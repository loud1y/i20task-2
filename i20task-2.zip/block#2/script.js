let amount;
let card = 0;
amount = getAmount();



$(".images-column>div").on("mouseenter", function() {
    const image = $(this).css("background-image");
    $("#main-image").css("background-image", image);
});


function getAmount() {
    amount = $("#quantity").text();
    return (amount);
}

function setAmount(newAmount) {
    amount = newAmount;
    $("#quantity").text(newAmount);
}

$(".btn-counter").on("click", function() {
    let temp = getAmount();
    if ($(this).hasClass("decrement-btn")) { //уменьшение
        if (temp > 1) temp--;
    } else { //увеличение
        temp++;
    }
    if (temp != 1) {
        $(".decrement-btn").addClass("btn-counter-active");
    } else {
        $(".decrement-btn").removeClass("btn-counter-active");
    }
    setAmount(temp);
    console.log(temp);
});

$("#to-store").on("click", function() {
    card += parseInt(amount);
    $.toast({
        text: `В корзину добавлены товары (х<b>${amount}</b>)\nТоваров в корзине: <b>${card}</b>`,
        showHideTransition: 'slide', // It can be plain, fade or slide
        bgColor: '#fff', // Background color for toast
        textColor: '#222', // text color
        allowToastClose: false, // Show the close button or not
        hideAfter: 5000, // `false` to make it sticky or time in miliseconds to hide after
        stack: 5, // `fakse` to show one stack at a time count showing the number of toasts that can be shown at once
        textAlign: 'left', // Alignment of text i.e. left, right, center
        position: 'bottom-right' // bottom-left or bottom-right or bottom-center or top-left or top-right or top-center or mid-center or an object representing the left, right, top, bottom values to position the toast on page
    })
});

$(document).ready(function() {

});