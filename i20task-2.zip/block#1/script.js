$(".images-column>div").on("mouseenter", function() {
    const image = $(this).css("background-image");
    $("#main-image").css("background-image", image);
});


$(document).ready(function() {

});